﻿namespace QuizTuto
{
    partial class Exams
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.QTimeP = new System.Windows.Forms.DateTimePicker();
            this.QDateP = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.Q10 = new System.Windows.Forms.GroupBox();
            this.Q1004 = new System.Windows.Forms.RadioButton();
            this.Q1003 = new System.Windows.Forms.RadioButton();
            this.Q1002 = new System.Windows.Forms.RadioButton();
            this.Q1001 = new System.Windows.Forms.RadioButton();
            this.Q9 = new System.Windows.Forms.GroupBox();
            this.Q904 = new System.Windows.Forms.RadioButton();
            this.Q903 = new System.Windows.Forms.RadioButton();
            this.Q902 = new System.Windows.Forms.RadioButton();
            this.Q901 = new System.Windows.Forms.RadioButton();
            this.Q8 = new System.Windows.Forms.GroupBox();
            this.Q804 = new System.Windows.Forms.RadioButton();
            this.Q803 = new System.Windows.Forms.RadioButton();
            this.Q802 = new System.Windows.Forms.RadioButton();
            this.Q801 = new System.Windows.Forms.RadioButton();
            this.Q7 = new System.Windows.Forms.GroupBox();
            this.Q704 = new System.Windows.Forms.RadioButton();
            this.Q703 = new System.Windows.Forms.RadioButton();
            this.Q702 = new System.Windows.Forms.RadioButton();
            this.Q701 = new System.Windows.Forms.RadioButton();
            this.Q6 = new System.Windows.Forms.GroupBox();
            this.Q604 = new System.Windows.Forms.RadioButton();
            this.Q603 = new System.Windows.Forms.RadioButton();
            this.Q602 = new System.Windows.Forms.RadioButton();
            this.Q601 = new System.Windows.Forms.RadioButton();
            this.Q5 = new System.Windows.Forms.GroupBox();
            this.Q504 = new System.Windows.Forms.RadioButton();
            this.Q503 = new System.Windows.Forms.RadioButton();
            this.Q502 = new System.Windows.Forms.RadioButton();
            this.Q501 = new System.Windows.Forms.RadioButton();
            this.Q4 = new System.Windows.Forms.GroupBox();
            this.Q404 = new System.Windows.Forms.RadioButton();
            this.Q403 = new System.Windows.Forms.RadioButton();
            this.Q402 = new System.Windows.Forms.RadioButton();
            this.Q401 = new System.Windows.Forms.RadioButton();
            this.Q3 = new System.Windows.Forms.GroupBox();
            this.Q304 = new System.Windows.Forms.RadioButton();
            this.Q303 = new System.Windows.Forms.RadioButton();
            this.Q302 = new System.Windows.Forms.RadioButton();
            this.Q301 = new System.Windows.Forms.RadioButton();
            this.Q2 = new System.Windows.Forms.GroupBox();
            this.Q204 = new System.Windows.Forms.RadioButton();
            this.Q203 = new System.Windows.Forms.RadioButton();
            this.Q202 = new System.Windows.Forms.RadioButton();
            this.Q201 = new System.Windows.Forms.RadioButton();
            this.Q1 = new System.Windows.Forms.GroupBox();
            this.Q104 = new System.Windows.Forms.RadioButton();
            this.Q103 = new System.Windows.Forms.RadioButton();
            this.Q102 = new System.Windows.Forms.RadioButton();
            this.Q101 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.Q10.SuspendLayout();
            this.Q9.SuspendLayout();
            this.Q8.SuspendLayout();
            this.Q7.SuspendLayout();
            this.Q6.SuspendLayout();
            this.Q5.SuspendLayout();
            this.Q4.SuspendLayout();
            this.Q3.SuspendLayout();
            this.Q2.SuspendLayout();
            this.Q1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Khaki;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.QTimeP);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.QDateP);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.SubmitBtn);
            this.panel1.Controls.Add(this.Q10);
            this.panel1.Controls.Add(this.Q9);
            this.panel1.Controls.Add(this.Q8);
            this.panel1.Controls.Add(this.Q7);
            this.panel1.Controls.Add(this.Q6);
            this.panel1.Controls.Add(this.Q5);
            this.panel1.Controls.Add(this.Q4);
            this.panel1.Controls.Add(this.Q3);
            this.panel1.Controls.Add(this.Q2);
            this.panel1.Controls.Add(this.Q1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-22, -38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1626, 874);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // QTimeP
            // 
            this.QTimeP.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.QTimeP.Location = new System.Drawing.Point(764, 103);
            this.QTimeP.Name = "QTimeP";
            this.QTimeP.Size = new System.Drawing.Size(200, 22);
            this.QTimeP.TabIndex = 22;
            // 
            // QDateP
            // 
            this.QDateP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.QDateP.Location = new System.Drawing.Point(764, 61);
            this.QDateP.Name = "QDateP";
            this.QDateP.Size = new System.Drawing.Size(200, 22);
            this.QDateP.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1324, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 32);
            this.label5.TabIndex = 21;
            this.label5.Text = "Candidate";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1116, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 32);
            this.label4.TabIndex = 19;
            this.label4.Text = "Subject";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.Location = new System.Drawing.Point(452, 752);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(121, 73);
            this.SubmitBtn.TabIndex = 16;
            this.SubmitBtn.Text = "SUBMIT";
            this.SubmitBtn.UseVisualStyleBackColor = true;
            this.SubmitBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // Q10
            // 
            this.Q10.Controls.Add(this.Q1004);
            this.Q10.Controls.Add(this.Q1003);
            this.Q10.Controls.Add(this.Q1002);
            this.Q10.Controls.Add(this.Q1001);
            this.Q10.Location = new System.Drawing.Point(641, 543);
            this.Q10.Name = "Q10";
            this.Q10.Size = new System.Drawing.Size(323, 168);
            this.Q10.TabIndex = 15;
            this.Q10.TabStop = false;
            this.Q10.Text = "groupBox10";
            this.Q10.Enter += new System.EventHandler(this.groupBox10_Enter);
            // 
            // Q1004
            // 
            this.Q1004.AutoSize = true;
            this.Q1004.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q1004.Location = new System.Drawing.Point(48, 124);
            this.Q1004.Name = "Q1004";
            this.Q1004.Size = new System.Drawing.Size(95, 24);
            this.Q1004.TabIndex = 5;
            this.Q1004.Text = "Option1";
            this.Q1004.UseVisualStyleBackColor = true;
            // 
            // Q1003
            // 
            this.Q1003.AutoSize = true;
            this.Q1003.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q1003.Location = new System.Drawing.Point(48, 94);
            this.Q1003.Name = "Q1003";
            this.Q1003.Size = new System.Drawing.Size(95, 24);
            this.Q1003.TabIndex = 4;
            this.Q1003.Text = "Option1";
            this.Q1003.UseVisualStyleBackColor = true;
            // 
            // Q1002
            // 
            this.Q1002.AutoSize = true;
            this.Q1002.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q1002.Location = new System.Drawing.Point(48, 64);
            this.Q1002.Name = "Q1002";
            this.Q1002.Size = new System.Drawing.Size(95, 24);
            this.Q1002.TabIndex = 3;
            this.Q1002.Text = "Option1";
            this.Q1002.UseVisualStyleBackColor = true;
            // 
            // Q1001
            // 
            this.Q1001.AutoSize = true;
            this.Q1001.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q1001.Location = new System.Drawing.Point(48, 36);
            this.Q1001.Name = "Q1001";
            this.Q1001.Size = new System.Drawing.Size(95, 24);
            this.Q1001.TabIndex = 0;
            this.Q1001.Text = "Option1";
            this.Q1001.UseVisualStyleBackColor = true;
            // 
            // Q9
            // 
            this.Q9.Controls.Add(this.Q904);
            this.Q9.Controls.Add(this.Q903);
            this.Q9.Controls.Add(this.Q902);
            this.Q9.Controls.Add(this.Q901);
            this.Q9.Location = new System.Drawing.Point(250, 543);
            this.Q9.Name = "Q9";
            this.Q9.Size = new System.Drawing.Size(323, 168);
            this.Q9.TabIndex = 14;
            this.Q9.TabStop = false;
            this.Q9.Text = "groupBox9";
            // 
            // Q904
            // 
            this.Q904.AutoSize = true;
            this.Q904.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q904.Location = new System.Drawing.Point(48, 124);
            this.Q904.Name = "Q904";
            this.Q904.Size = new System.Drawing.Size(95, 24);
            this.Q904.TabIndex = 5;
            this.Q904.Text = "Option1";
            this.Q904.UseVisualStyleBackColor = true;
            // 
            // Q903
            // 
            this.Q903.AutoSize = true;
            this.Q903.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q903.Location = new System.Drawing.Point(48, 94);
            this.Q903.Name = "Q903";
            this.Q903.Size = new System.Drawing.Size(95, 24);
            this.Q903.TabIndex = 4;
            this.Q903.Text = "Option1";
            this.Q903.UseVisualStyleBackColor = true;
            // 
            // Q902
            // 
            this.Q902.AutoSize = true;
            this.Q902.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q902.Location = new System.Drawing.Point(48, 64);
            this.Q902.Name = "Q902";
            this.Q902.Size = new System.Drawing.Size(95, 24);
            this.Q902.TabIndex = 3;
            this.Q902.Text = "Option1";
            this.Q902.UseVisualStyleBackColor = true;
            // 
            // Q901
            // 
            this.Q901.AutoSize = true;
            this.Q901.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q901.Location = new System.Drawing.Point(48, 36);
            this.Q901.Name = "Q901";
            this.Q901.Size = new System.Drawing.Size(95, 24);
            this.Q901.TabIndex = 0;
            this.Q901.Text = "Option1";
            this.Q901.UseVisualStyleBackColor = true;
            // 
            // Q8
            // 
            this.Q8.Controls.Add(this.Q804);
            this.Q8.Controls.Add(this.Q803);
            this.Q8.Controls.Add(this.Q802);
            this.Q8.Controls.Add(this.Q801);
            this.Q8.Location = new System.Drawing.Point(1131, 339);
            this.Q8.Name = "Q8";
            this.Q8.Size = new System.Drawing.Size(323, 168);
            this.Q8.TabIndex = 13;
            this.Q8.TabStop = false;
            this.Q8.Text = "groupBox5";
            // 
            // Q804
            // 
            this.Q804.AutoSize = true;
            this.Q804.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q804.Location = new System.Drawing.Point(48, 124);
            this.Q804.Name = "Q804";
            this.Q804.Size = new System.Drawing.Size(95, 24);
            this.Q804.TabIndex = 5;
            this.Q804.Text = "Option1";
            this.Q804.UseVisualStyleBackColor = true;
            // 
            // Q803
            // 
            this.Q803.AutoSize = true;
            this.Q803.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q803.Location = new System.Drawing.Point(48, 94);
            this.Q803.Name = "Q803";
            this.Q803.Size = new System.Drawing.Size(95, 24);
            this.Q803.TabIndex = 4;
            this.Q803.Text = "Option1";
            this.Q803.UseVisualStyleBackColor = true;
            // 
            // Q802
            // 
            this.Q802.AutoSize = true;
            this.Q802.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q802.Location = new System.Drawing.Point(48, 64);
            this.Q802.Name = "Q802";
            this.Q802.Size = new System.Drawing.Size(95, 24);
            this.Q802.TabIndex = 3;
            this.Q802.Text = "Option1";
            this.Q802.UseVisualStyleBackColor = true;
            // 
            // Q801
            // 
            this.Q801.AutoSize = true;
            this.Q801.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q801.Location = new System.Drawing.Point(48, 36);
            this.Q801.Name = "Q801";
            this.Q801.Size = new System.Drawing.Size(95, 24);
            this.Q801.TabIndex = 0;
            this.Q801.Text = "Option1";
            this.Q801.UseVisualStyleBackColor = true;
            // 
            // Q7
            // 
            this.Q7.Controls.Add(this.Q704);
            this.Q7.Controls.Add(this.Q703);
            this.Q7.Controls.Add(this.Q702);
            this.Q7.Controls.Add(this.Q701);
            this.Q7.Location = new System.Drawing.Point(776, 339);
            this.Q7.Name = "Q7";
            this.Q7.Size = new System.Drawing.Size(323, 168);
            this.Q7.TabIndex = 12;
            this.Q7.TabStop = false;
            this.Q7.Text = "groupBox6";
            // 
            // Q704
            // 
            this.Q704.AutoSize = true;
            this.Q704.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q704.Location = new System.Drawing.Point(48, 124);
            this.Q704.Name = "Q704";
            this.Q704.Size = new System.Drawing.Size(95, 24);
            this.Q704.TabIndex = 5;
            this.Q704.Text = "Option1";
            this.Q704.UseVisualStyleBackColor = true;
            // 
            // Q703
            // 
            this.Q703.AutoSize = true;
            this.Q703.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q703.Location = new System.Drawing.Point(48, 94);
            this.Q703.Name = "Q703";
            this.Q703.Size = new System.Drawing.Size(95, 24);
            this.Q703.TabIndex = 4;
            this.Q703.Text = "Option1";
            this.Q703.UseVisualStyleBackColor = true;
            // 
            // Q702
            // 
            this.Q702.AutoSize = true;
            this.Q702.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q702.Location = new System.Drawing.Point(48, 64);
            this.Q702.Name = "Q702";
            this.Q702.Size = new System.Drawing.Size(95, 24);
            this.Q702.TabIndex = 3;
            this.Q702.Text = "Option1";
            this.Q702.UseVisualStyleBackColor = true;
            // 
            // Q701
            // 
            this.Q701.AutoSize = true;
            this.Q701.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q701.Location = new System.Drawing.Point(48, 36);
            this.Q701.Name = "Q701";
            this.Q701.Size = new System.Drawing.Size(95, 24);
            this.Q701.TabIndex = 0;
            this.Q701.Text = "Option1";
            this.Q701.UseVisualStyleBackColor = true;
            // 
            // Q6
            // 
            this.Q6.Controls.Add(this.Q604);
            this.Q6.Controls.Add(this.Q603);
            this.Q6.Controls.Add(this.Q602);
            this.Q6.Controls.Add(this.Q601);
            this.Q6.Location = new System.Drawing.Point(414, 339);
            this.Q6.Name = "Q6";
            this.Q6.Size = new System.Drawing.Size(323, 168);
            this.Q6.TabIndex = 11;
            this.Q6.TabStop = false;
            this.Q6.Text = "groupBox7";
            // 
            // Q604
            // 
            this.Q604.AutoSize = true;
            this.Q604.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q604.Location = new System.Drawing.Point(48, 124);
            this.Q604.Name = "Q604";
            this.Q604.Size = new System.Drawing.Size(95, 24);
            this.Q604.TabIndex = 5;
            this.Q604.Text = "Option1";
            this.Q604.UseVisualStyleBackColor = true;
            // 
            // Q603
            // 
            this.Q603.AutoSize = true;
            this.Q603.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q603.Location = new System.Drawing.Point(48, 94);
            this.Q603.Name = "Q603";
            this.Q603.Size = new System.Drawing.Size(95, 24);
            this.Q603.TabIndex = 4;
            this.Q603.Text = "Option1";
            this.Q603.UseVisualStyleBackColor = true;
            // 
            // Q602
            // 
            this.Q602.AutoSize = true;
            this.Q602.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q602.Location = new System.Drawing.Point(48, 64);
            this.Q602.Name = "Q602";
            this.Q602.Size = new System.Drawing.Size(95, 24);
            this.Q602.TabIndex = 3;
            this.Q602.Text = "Option1";
            this.Q602.UseVisualStyleBackColor = true;
            this.Q602.CheckedChanged += new System.EventHandler(this.radioButton27_CheckedChanged);
            // 
            // Q601
            // 
            this.Q601.AutoSize = true;
            this.Q601.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q601.Location = new System.Drawing.Point(48, 36);
            this.Q601.Name = "Q601";
            this.Q601.Size = new System.Drawing.Size(95, 24);
            this.Q601.TabIndex = 0;
            this.Q601.Text = "Option1";
            this.Q601.UseVisualStyleBackColor = true;
            // 
            // Q5
            // 
            this.Q5.Controls.Add(this.Q504);
            this.Q5.Controls.Add(this.Q503);
            this.Q5.Controls.Add(this.Q502);
            this.Q5.Controls.Add(this.Q501);
            this.Q5.Location = new System.Drawing.Point(58, 339);
            this.Q5.Name = "Q5";
            this.Q5.Size = new System.Drawing.Size(323, 168);
            this.Q5.TabIndex = 10;
            this.Q5.TabStop = false;
            this.Q5.Text = "groupBox8";
            // 
            // Q504
            // 
            this.Q504.AutoSize = true;
            this.Q504.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q504.Location = new System.Drawing.Point(48, 124);
            this.Q504.Name = "Q504";
            this.Q504.Size = new System.Drawing.Size(95, 24);
            this.Q504.TabIndex = 5;
            this.Q504.Text = "Option1";
            this.Q504.UseVisualStyleBackColor = true;
            // 
            // Q503
            // 
            this.Q503.AutoSize = true;
            this.Q503.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q503.Location = new System.Drawing.Point(48, 94);
            this.Q503.Name = "Q503";
            this.Q503.Size = new System.Drawing.Size(95, 24);
            this.Q503.TabIndex = 4;
            this.Q503.Text = "Option1";
            this.Q503.UseVisualStyleBackColor = true;
            // 
            // Q502
            // 
            this.Q502.AutoSize = true;
            this.Q502.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q502.Location = new System.Drawing.Point(48, 64);
            this.Q502.Name = "Q502";
            this.Q502.Size = new System.Drawing.Size(95, 24);
            this.Q502.TabIndex = 3;
            this.Q502.Text = "Option1";
            this.Q502.UseVisualStyleBackColor = true;
            // 
            // Q501
            // 
            this.Q501.AutoSize = true;
            this.Q501.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q501.Location = new System.Drawing.Point(48, 36);
            this.Q501.Name = "Q501";
            this.Q501.Size = new System.Drawing.Size(95, 24);
            this.Q501.TabIndex = 0;
            this.Q501.Text = "Option1";
            this.Q501.UseVisualStyleBackColor = true;
            // 
            // Q4
            // 
            this.Q4.Controls.Add(this.Q404);
            this.Q4.Controls.Add(this.Q403);
            this.Q4.Controls.Add(this.Q402);
            this.Q4.Controls.Add(this.Q401);
            this.Q4.Location = new System.Drawing.Point(1131, 144);
            this.Q4.Name = "Q4";
            this.Q4.Size = new System.Drawing.Size(323, 168);
            this.Q4.TabIndex = 9;
            this.Q4.TabStop = false;
            this.Q4.Text = "groupBox4";
            // 
            // Q404
            // 
            this.Q404.AutoSize = true;
            this.Q404.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q404.Location = new System.Drawing.Point(48, 124);
            this.Q404.Name = "Q404";
            this.Q404.Size = new System.Drawing.Size(95, 24);
            this.Q404.TabIndex = 5;
            this.Q404.Text = "Option1";
            this.Q404.UseVisualStyleBackColor = true;
            // 
            // Q403
            // 
            this.Q403.AutoSize = true;
            this.Q403.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q403.Location = new System.Drawing.Point(48, 94);
            this.Q403.Name = "Q403";
            this.Q403.Size = new System.Drawing.Size(95, 24);
            this.Q403.TabIndex = 4;
            this.Q403.Text = "Option1";
            this.Q403.UseVisualStyleBackColor = true;
            // 
            // Q402
            // 
            this.Q402.AutoSize = true;
            this.Q402.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q402.Location = new System.Drawing.Point(48, 64);
            this.Q402.Name = "Q402";
            this.Q402.Size = new System.Drawing.Size(95, 24);
            this.Q402.TabIndex = 3;
            this.Q402.Text = "Option1";
            this.Q402.UseVisualStyleBackColor = true;
            // 
            // Q401
            // 
            this.Q401.AutoSize = true;
            this.Q401.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q401.Location = new System.Drawing.Point(48, 36);
            this.Q401.Name = "Q401";
            this.Q401.Size = new System.Drawing.Size(95, 24);
            this.Q401.TabIndex = 0;
            this.Q401.Text = "Option1";
            this.Q401.UseVisualStyleBackColor = true;
            // 
            // Q3
            // 
            this.Q3.Controls.Add(this.Q304);
            this.Q3.Controls.Add(this.Q303);
            this.Q3.Controls.Add(this.Q302);
            this.Q3.Controls.Add(this.Q301);
            this.Q3.Location = new System.Drawing.Point(776, 144);
            this.Q3.Name = "Q3";
            this.Q3.Size = new System.Drawing.Size(323, 168);
            this.Q3.TabIndex = 8;
            this.Q3.TabStop = false;
            this.Q3.Text = "groupBox3";
            // 
            // Q304
            // 
            this.Q304.AutoSize = true;
            this.Q304.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q304.Location = new System.Drawing.Point(48, 124);
            this.Q304.Name = "Q304";
            this.Q304.Size = new System.Drawing.Size(95, 24);
            this.Q304.TabIndex = 5;
            this.Q304.Text = "Option1";
            this.Q304.UseVisualStyleBackColor = true;
            // 
            // Q303
            // 
            this.Q303.AutoSize = true;
            this.Q303.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q303.Location = new System.Drawing.Point(48, 94);
            this.Q303.Name = "Q303";
            this.Q303.Size = new System.Drawing.Size(95, 24);
            this.Q303.TabIndex = 4;
            this.Q303.Text = "Option1";
            this.Q303.UseVisualStyleBackColor = true;
            // 
            // Q302
            // 
            this.Q302.AutoSize = true;
            this.Q302.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q302.Location = new System.Drawing.Point(48, 64);
            this.Q302.Name = "Q302";
            this.Q302.Size = new System.Drawing.Size(95, 24);
            this.Q302.TabIndex = 3;
            this.Q302.Text = "Option1";
            this.Q302.UseVisualStyleBackColor = true;
            // 
            // Q301
            // 
            this.Q301.AutoSize = true;
            this.Q301.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q301.Location = new System.Drawing.Point(48, 36);
            this.Q301.Name = "Q301";
            this.Q301.Size = new System.Drawing.Size(95, 24);
            this.Q301.TabIndex = 0;
            this.Q301.Text = "Option1";
            this.Q301.UseVisualStyleBackColor = true;
            this.Q301.CheckedChanged += new System.EventHandler(this.radioButton12_CheckedChanged);
            // 
            // Q2
            // 
            this.Q2.Controls.Add(this.Q204);
            this.Q2.Controls.Add(this.Q203);
            this.Q2.Controls.Add(this.Q202);
            this.Q2.Controls.Add(this.Q201);
            this.Q2.Location = new System.Drawing.Point(414, 144);
            this.Q2.Name = "Q2";
            this.Q2.Size = new System.Drawing.Size(323, 168);
            this.Q2.TabIndex = 7;
            this.Q2.TabStop = false;
            this.Q2.Text = "groupBox2";
            this.Q2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // Q204
            // 
            this.Q204.AutoSize = true;
            this.Q204.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q204.Location = new System.Drawing.Point(48, 124);
            this.Q204.Name = "Q204";
            this.Q204.Size = new System.Drawing.Size(95, 24);
            this.Q204.TabIndex = 5;
            this.Q204.Text = "Option1";
            this.Q204.UseVisualStyleBackColor = true;
            // 
            // Q203
            // 
            this.Q203.AutoSize = true;
            this.Q203.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q203.Location = new System.Drawing.Point(48, 94);
            this.Q203.Name = "Q203";
            this.Q203.Size = new System.Drawing.Size(95, 24);
            this.Q203.TabIndex = 4;
            this.Q203.Text = "Option1";
            this.Q203.UseVisualStyleBackColor = true;
            // 
            // Q202
            // 
            this.Q202.AutoSize = true;
            this.Q202.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q202.Location = new System.Drawing.Point(48, 64);
            this.Q202.Name = "Q202";
            this.Q202.Size = new System.Drawing.Size(95, 24);
            this.Q202.TabIndex = 3;
            this.Q202.Text = "Option1";
            this.Q202.UseVisualStyleBackColor = true;
            // 
            // Q201
            // 
            this.Q201.AutoSize = true;
            this.Q201.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q201.Location = new System.Drawing.Point(48, 36);
            this.Q201.Name = "Q201";
            this.Q201.Size = new System.Drawing.Size(95, 24);
            this.Q201.TabIndex = 0;
            this.Q201.Text = "Option1";
            this.Q201.UseVisualStyleBackColor = true;
            // 
            // Q1
            // 
            this.Q1.Controls.Add(this.Q104);
            this.Q1.Controls.Add(this.Q103);
            this.Q1.Controls.Add(this.Q102);
            this.Q1.Controls.Add(this.Q101);
            this.Q1.Location = new System.Drawing.Point(58, 144);
            this.Q1.Name = "Q1";
            this.Q1.Size = new System.Drawing.Size(323, 168);
            this.Q1.TabIndex = 6;
            this.Q1.TabStop = false;
            this.Q1.Text = "groupBox1";
            // 
            // Q104
            // 
            this.Q104.AutoSize = true;
            this.Q104.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q104.Location = new System.Drawing.Point(48, 124);
            this.Q104.Name = "Q104";
            this.Q104.Size = new System.Drawing.Size(95, 24);
            this.Q104.TabIndex = 5;
            this.Q104.Text = "Option1";
            this.Q104.UseVisualStyleBackColor = true;
            // 
            // Q103
            // 
            this.Q103.AutoSize = true;
            this.Q103.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q103.Location = new System.Drawing.Point(48, 94);
            this.Q103.Name = "Q103";
            this.Q103.Size = new System.Drawing.Size(95, 24);
            this.Q103.TabIndex = 4;
            this.Q103.Text = "Option1";
            this.Q103.UseVisualStyleBackColor = true;
            this.Q103.CheckedChanged += new System.EventHandler(this.Q103_CheckedChanged);
            // 
            // Q102
            // 
            this.Q102.AutoSize = true;
            this.Q102.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q102.Location = new System.Drawing.Point(48, 64);
            this.Q102.Name = "Q102";
            this.Q102.Size = new System.Drawing.Size(95, 24);
            this.Q102.TabIndex = 3;
            this.Q102.Text = "Option1";
            this.Q102.UseVisualStyleBackColor = true;
            this.Q102.CheckedChanged += new System.EventHandler(this.Q102_CheckedChanged);
            // 
            // Q101
            // 
            this.Q101.AutoSize = true;
            this.Q101.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q101.Location = new System.Drawing.Point(48, 36);
            this.Q101.Name = "Q101";
            this.Q101.Size = new System.Drawing.Size(95, 24);
            this.Q101.TabIndex = 0;
            this.Q101.Text = "Option1";
            this.Q101.UseVisualStyleBackColor = true;
            this.Q101.CheckedChanged += new System.EventHandler(this.Q101_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(613, 73);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(78, 10);
            this.panel3.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(607, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 32);
            this.label3.TabIndex = 3;
            this.label3.Text = "QUIZ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 46);
            this.label1.TabIndex = 1;
            this.label1.Text = "IT CLASS QUIZ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1484, 47);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 102);
            this.button1.TabIndex = 44;
            this.button1.Text = "HELP";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Exams
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1583, 799);
            this.Controls.Add(this.panel1);
            this.Name = "Exams";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exams";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Q10.ResumeLayout(false);
            this.Q10.PerformLayout();
            this.Q9.ResumeLayout(false);
            this.Q9.PerformLayout();
            this.Q8.ResumeLayout(false);
            this.Q8.PerformLayout();
            this.Q7.ResumeLayout(false);
            this.Q7.PerformLayout();
            this.Q6.ResumeLayout(false);
            this.Q6.PerformLayout();
            this.Q5.ResumeLayout(false);
            this.Q5.PerformLayout();
            this.Q4.ResumeLayout(false);
            this.Q4.PerformLayout();
            this.Q3.ResumeLayout(false);
            this.Q3.PerformLayout();
            this.Q2.ResumeLayout(false);
            this.Q2.PerformLayout();
            this.Q1.ResumeLayout(false);
            this.Q1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox Q1;
        private System.Windows.Forms.RadioButton Q101;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox Q8;
        private System.Windows.Forms.RadioButton Q804;
        private System.Windows.Forms.RadioButton Q803;
        private System.Windows.Forms.RadioButton Q802;
        private System.Windows.Forms.RadioButton Q801;
        private System.Windows.Forms.GroupBox Q7;
        private System.Windows.Forms.RadioButton Q704;
        private System.Windows.Forms.RadioButton Q703;
        private System.Windows.Forms.RadioButton Q702;
        private System.Windows.Forms.RadioButton Q701;
        private System.Windows.Forms.GroupBox Q6;
        private System.Windows.Forms.RadioButton Q604;
        private System.Windows.Forms.RadioButton Q603;
        private System.Windows.Forms.RadioButton Q602;
        private System.Windows.Forms.RadioButton Q601;
        private System.Windows.Forms.GroupBox Q5;
        private System.Windows.Forms.RadioButton Q504;
        private System.Windows.Forms.RadioButton Q503;
        private System.Windows.Forms.RadioButton Q502;
        private System.Windows.Forms.RadioButton Q501;
        private System.Windows.Forms.GroupBox Q4;
        private System.Windows.Forms.RadioButton Q404;
        private System.Windows.Forms.RadioButton Q403;
        private System.Windows.Forms.RadioButton Q402;
        private System.Windows.Forms.RadioButton Q401;
        private System.Windows.Forms.GroupBox Q3;
        private System.Windows.Forms.RadioButton Q304;
        private System.Windows.Forms.RadioButton Q303;
        private System.Windows.Forms.RadioButton Q302;
        private System.Windows.Forms.RadioButton Q301;
        private System.Windows.Forms.GroupBox Q2;
        private System.Windows.Forms.RadioButton Q204;
        private System.Windows.Forms.RadioButton Q203;
        private System.Windows.Forms.RadioButton Q202;
        private System.Windows.Forms.RadioButton Q201;
        private System.Windows.Forms.RadioButton Q104;
        private System.Windows.Forms.RadioButton Q103;
        private System.Windows.Forms.RadioButton Q102;
        private System.Windows.Forms.GroupBox Q10;
        private System.Windows.Forms.RadioButton Q1004;
        private System.Windows.Forms.RadioButton Q1003;
        private System.Windows.Forms.RadioButton Q1002;
        private System.Windows.Forms.RadioButton Q1001;
        private System.Windows.Forms.GroupBox Q9;
        private System.Windows.Forms.RadioButton Q904;
        private System.Windows.Forms.RadioButton Q903;
        private System.Windows.Forms.RadioButton Q902;
        private System.Windows.Forms.RadioButton Q901;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button SubmitBtn;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker QTimeP;
        private System.Windows.Forms.DateTimePicker QDateP;
        private System.Windows.Forms.Button button1;
    }
}