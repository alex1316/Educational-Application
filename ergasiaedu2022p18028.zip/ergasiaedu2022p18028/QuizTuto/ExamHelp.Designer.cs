﻿namespace QuizTuto
{
    partial class ExamHelp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Q1 = new System.Windows.Forms.GroupBox();
            this.Q104 = new System.Windows.Forms.RadioButton();
            this.Q103 = new System.Windows.Forms.RadioButton();
            this.Q102 = new System.Windows.Forms.RadioButton();
            this.Q101 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.QDateP = new System.Windows.Forms.DateTimePicker();
            this.QTimeP = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Q1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Q1
            // 
            this.Q1.Controls.Add(this.Q104);
            this.Q1.Controls.Add(this.Q103);
            this.Q1.Controls.Add(this.Q102);
            this.Q1.Controls.Add(this.Q101);
            this.Q1.Location = new System.Drawing.Point(56, 54);
            this.Q1.Name = "Q1";
            this.Q1.Size = new System.Drawing.Size(323, 168);
            this.Q1.TabIndex = 7;
            this.Q1.TabStop = false;
            this.Q1.Text = "groupBox1";
            // 
            // Q104
            // 
            this.Q104.AutoSize = true;
            this.Q104.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q104.Location = new System.Drawing.Point(48, 124);
            this.Q104.Name = "Q104";
            this.Q104.Size = new System.Drawing.Size(95, 24);
            this.Q104.TabIndex = 5;
            this.Q104.Text = "Option1";
            this.Q104.UseVisualStyleBackColor = true;
            // 
            // Q103
            // 
            this.Q103.AutoSize = true;
            this.Q103.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q103.Location = new System.Drawing.Point(48, 94);
            this.Q103.Name = "Q103";
            this.Q103.Size = new System.Drawing.Size(95, 24);
            this.Q103.TabIndex = 4;
            this.Q103.Text = "Option1";
            this.Q103.UseVisualStyleBackColor = true;
            // 
            // Q102
            // 
            this.Q102.AutoSize = true;
            this.Q102.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q102.Location = new System.Drawing.Point(48, 64);
            this.Q102.Name = "Q102";
            this.Q102.Size = new System.Drawing.Size(95, 24);
            this.Q102.TabIndex = 3;
            this.Q102.Text = "Option1";
            this.Q102.UseVisualStyleBackColor = true;
            // 
            // Q101
            // 
            this.Q101.AutoSize = true;
            this.Q101.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q101.Location = new System.Drawing.Point(48, 36);
            this.Q101.Name = "Q101";
            this.Q101.Size = new System.Drawing.Size(95, 24);
            this.Q101.TabIndex = 0;
            this.Q101.Text = "Option1";
            this.Q101.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(402, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(448, 25);
            this.label2.TabIndex = 38;
            this.label2.Text = "Εδω γινεται επιλογη της απαντησης του μαθητη";
            // 
            // QDateP
            // 
            this.QDateP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.QDateP.Location = new System.Drawing.Point(104, 261);
            this.QDateP.Name = "QDateP";
            this.QDateP.Size = new System.Drawing.Size(200, 22);
            this.QDateP.TabIndex = 39;
            // 
            // QTimeP
            // 
            this.QTimeP.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.QTimeP.Location = new System.Drawing.Point(104, 330);
            this.QTimeP.Name = "QTimeP";
            this.QTimeP.Size = new System.Drawing.Size(200, 22);
            this.QTimeP.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(132, 402);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 32);
            this.label4.TabIndex = 41;
            this.label4.Text = "Subject";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(113, 482);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 32);
            this.label5.TabIndex = 42;
            this.label5.Text = "Candidate";
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.Location = new System.Drawing.Point(119, 573);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(121, 73);
            this.SubmitBtn.TabIndex = 43;
            this.SubmitBtn.Text = "SUBMIT";
            this.SubmitBtn.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(347, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 25);
            this.label1.TabIndex = 44;
            this.label1.Text = "Ημερομηνια";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(356, 328);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 25);
            this.label3.TabIndex = 45;
            this.label3.Text = "Ωρα";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(336, 402);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(320, 25);
            this.label6.TabIndex = 46;
            this.label6.Text = "Εμφανιση επιλεγμενου μαθηματος";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(336, 472);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(200, 25);
            this.label7.TabIndex = 47;
            this.label7.Text = "Εμφανιση υποψηφιου";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(325, 594);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(313, 25);
            this.label8.TabIndex = 48;
            this.label8.Text = "Αποθυκευση απαντησεων μαθητη";
            // 
            // ExamHelp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 746);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SubmitBtn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.QTimeP);
            this.Controls.Add(this.QDateP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Q1);
            this.Name = "ExamHelp";
            this.Text = "ExamHelp";
            this.Q1.ResumeLayout(false);
            this.Q1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox Q1;
        private System.Windows.Forms.RadioButton Q104;
        private System.Windows.Forms.RadioButton Q103;
        private System.Windows.Forms.RadioButton Q102;
        private System.Windows.Forms.RadioButton Q101;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker QDateP;
        private System.Windows.Forms.DateTimePicker QTimeP;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button SubmitBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}